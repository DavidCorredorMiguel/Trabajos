// Primer ejemplo en C

main(){
	// Mostramos por consola
	printf("Vamos Chavales!!! ;)");
	// Declaraci�n de variables
	int edad=18; // Introduce n�mero
	float e = (float)edad; // Mostrar coma
	printf ("\nedad:%f", e);
	float ed=18.15; // Introduce n�mero con coma
	printf ("\nedad:%f", ed); // Mostrar n�mero con coma
	edad = (int)ed;
	printf ("\nedad:%d", edad); // Mostrar n�mero
}

/*
Lee un fichero linea a linea
*/
#include <stdio.h>
main(){
	FILE *fichero;
	char linea[80];
	fichero = fopen("datos.txt", "r");
	//LECTURA DE UNA LINEA
	fscanf(fichero, "%s", linea);
	printf("%s\n", linea);
	//LECTURA DE TODAS LAS LINEAS
	while((fscanf(fichero, "%s", linea))!=EOF){
		printf("%s\n");
	}
	fclose(fichero);
}

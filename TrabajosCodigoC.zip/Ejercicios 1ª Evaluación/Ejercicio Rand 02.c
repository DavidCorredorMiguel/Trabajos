#include <stdlib.h>
main(){
	int dado1, dado2, dados;
	char letra='f';
	srand (getpid());
	do{
		printf("Lanza los dados\n");
		dado1=(rand()%6+1);
		dado2=(rand()%6+1);
		printf("\nDado 1: %d", dado1);
		printf("\nDado 2: %d", dado2);
		dados=dado1+dado2;
		if(dados>=10){
			printf("\nEnhorabuena has acertado!!");
		}else{
			printf("\nVuelve a intentarlo");
		}printf("\nPulse otra tecla");
		letra=getch();
	}while(letra !='f');
	return 0;
}

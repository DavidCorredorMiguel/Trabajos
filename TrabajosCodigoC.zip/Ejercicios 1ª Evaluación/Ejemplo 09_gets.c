#include <stdio.h>

main(){
	char nombre[20];	// Nombre usuario
	char apellido[25];	// Primer apellido
	int edad;			// Edad actual
	char municipio[30];	// Municipio de residencia
	int cp;				// C�digo Postal
	
	printf("Introduzca su nombre: ");
	gets(nombre);
	printf("Introduzca su apellido: ");
	gets(apellido);
	printf("Introduzca su edad: ");
	scanf("%d", &edad);
	
	// Despu�s de introducir un n�mero y antes de introducir
	// una cadena de caracteres pondremos la siguiente l�nea
	while(getchar()!='\n');
	
	printf("Introduzca su municipio: ");
	gets(municipio);
	printf("Introduzca su codigo postal: ");
	scanf("%d", &cp);
	
	// Mostrar datos almacenados
	printf("\n===============================\n");
	printf("Datos del usuario\n");
	printf("Nombre: %s\n", nombre);
	printf("Apellido: %s\n", apellido);
	printf("Edad: %d\n", edad);
	printf("Municipio: %s\n", municipio);
	printf("Codigo Postal: %d\n", cp);
	
}

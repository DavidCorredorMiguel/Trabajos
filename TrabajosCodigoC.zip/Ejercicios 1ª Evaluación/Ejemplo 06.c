// Bucle while

main(){
	int numero=1;		// inicializaci�n
	// Mostramos del 1 al 200
	while(numero <= 200){	// Condicci�n mientras
		printf("%d ", numero);
		numero++;	// Incremento
	}
	printf("\n\n===================================\n", numero);	
	numero=200;		// inicializaci�n
	// mostramos del 200 al 1
	while(numero >=1){	// Condicci�n mientras
		printf("%d ", numero);
		numero--;	// Incremento
	}
	printf("\n\n===================================\n", numero);
	numero=2;		// inicializaci�n
	// Mostramos del 1 al 200 solo los pares
	while(numero <= 200){	// Condicci�n mientras
		printf("%d ", numero);
		numero+=2;	// Incremento
	}
	printf("\n\n===================================\n", numero);
	numero=1;		// inicializaci�n
	// Mostramos del 1 al 200 solo los impares
	while(numero <= 200){	// Condicci�n mientras
		printf("%d ", numero);
		numero+=2;	// Incremento
	}
	printf("\n\n===================================\n", numero);
	numero=1;		// inicializaci�n
	// Mostramos del 1 al 200 saltando cada 10 n�meros
	while(numero <= 200){	// Condicci�n mientras
		printf("%d, ", numero);	
		if(numero%10 == 0){
		printf("\n");
		}
		numero++;	// Incremento
	}
}

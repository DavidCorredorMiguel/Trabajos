// Explicaci�n del printf
main(){
	// Declaraci�n de variables
	int entero = 65; // Introduce n�mero
	float decimal = 45.98; // Introduce n�mero con coma
	char letra = '#'; // Introduce caracter
	// printf 
	printf("\nSolo muestro texto");
	// printf con caracter
	printf("\nLa letra es: %c", letra);
	// printf con entero
	printf("\nEntero: %d", entero);
	// printf con decimal
	printf("\nDecimal: %g", decimal);
	// printf con entero y decimal
	printf("\nEntero: %d, decimal: %.2f", entero, decimal);
}

main(){
	// Inicializaci�n de variables
	int num;
	// Bucle for 1 al 200
	for(num=1; num<=200; num++){ // Estructura de repetici�n
		if(num == 200){ // Estructura de selecci�n
			printf("%d.", num);
		}else{ // Estructura de selecci�n
			printf("%d, ", num);
		}
	}
	printf("\n\n===================================\n", num);
	// Bucle for 1 al 200 solo pares
	for(num=2; num<=200; num+= 2){ // Estructura de repetici�n
		if(num == 200){ // Estructura de selecci�n
			printf("%d.", num);
		}else{ // Estructura de selecci�n
			printf("%d, ", num);
		}
	}
	printf("\n\n===================================\n", num);
	// Bucle for del 200 al 1
	for(num=200; num>=1; num--){ // Estructura de repetici�n
		if(num==1){ // Estructura de selecci�n
			printf("%d.", num);
		}else{ // Estructura de selecci�n
			printf("%d,", num);
		}
	}
	printf("\n\n===================================\n", num);
	for(num=1; num<=200; num++){ // Estructura de repetici�n
		if(num%10==0){ // Estructura de selecci�n
			printf("%d\n", num);
		}
	}
}

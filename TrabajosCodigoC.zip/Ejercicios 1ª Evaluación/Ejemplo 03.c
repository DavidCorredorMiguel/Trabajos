// Uso de estructuras de selecci�n if
main(){
	int edad=4; // Introduce n�mero
	if (edad >= 65){ // Condici�n si
		printf("Te puedes juvilar"); // Mostar informaci�n
	}else if(edad < 18){ // Condici�n si
		printf("Estudia!!!"); // Mostar informaci�n
	}else if(edad < 5){ // Condici�n si
		printf("Descansa :)"); // Mostar informaci�n
	}else if(edad >= 52 && edad < 65){ // Condici�n si
		printf("Prejuvilate"); // Mostar informaci�n
	}else{ // Condici�n si
		printf("Ponte a trabajar"); // Mostar informaci�n
	}
}

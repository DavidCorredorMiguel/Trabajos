#include <stdio.h>
//Declarar funciones
char menu();
void opcion1();
void opcion2();
void opcion3();
void opcion4();
void opcion5();
void opcion6();
//main
int main(){
	char letra;
	do{
		letra = menu();
		switch(letra){
			case 'a':
				opcion1();
				break;
			case 'b':
				opcion2();
				break;
			case 'c':
				opcion3();
				break;
			case 'd':
				opcion4();
				break;
			case 'e':
				opcion5();
				break;
			case 'f':
				opcion6();
				break;	
			case 'z':
				system("cls");
				printf("Ha decidido usted salir del menu");
				break;					
		}
	}while(letra!='z');
	return 0;
}
//Instanciar funciones
char menu(){
	char opcion;
	printf("***********	MENU*************\n");
	printf("a. Del 1 al 10\n");
	printf("b. Del 10 al 1\n");
	printf("c. Pares del 1 al 10(Modulo)\n");
	printf("d. Pares del 1 al 10(Incremento)\n");
	printf("e. Impares del 10 al 1(Modulo)\n");
	printf("f. Impares del 10 al 1(Decremento)\n");
	printf("Elige una opcion: ");
	opcion = getch();	
	return opcion;
}
void opcion1(){
	system("cls");
	int num;
	for(num=1;num<=10;num++){
		printf("%d ", num);
	}
	printf("\n\n\n");
}
void opcion2(){
	system("cls");
	int num;
	for(num=10;num>=1;num--){
		printf("%d ", num);
	}
	printf("\n\n\n");
}
void opcion3(){
	system("cls");
	int num;
	for(num=1;num<=10;num++){
		if(num%2==00){
			printf("%d ", num);
		}	
	}
	printf("\n\n\n");
}
void opcion4(){
	system("cls");
	int num;
	for(num=2;num<=10;num+=2){
		printf("%d ", num);
	}
	printf("\n\n\n");
}
void opcion5(){
	system("cls");
	int num;
	for(num=10;num>=1;num--){
		if(num%2==1){
			printf("%d ", num);	
		}
	}
	printf("\n\n\n");
}
void opcion6(){
	system("cls");
	int num;
	for(num=9;num>=1;num-=2){
		printf("%d ", num);	
	}
	printf("\n\n\n");
}

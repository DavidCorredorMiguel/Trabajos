// Crea un array de 100 posiciones. Pide al usuario que inserte numeros enteros hasta introducir 0. Muestra el array. Ordena el array y muestral� de nuevo.
#include <stdio.h>
void numorden();
int main(){
	int numeros[100], numero;
	int cont=1;
	// Guardar en el array
	do{
		printf("Introduzca un numero: ");
		scanf("%d", &numero);
		if(numero != 0){
			numeros[cont] = numero;
			cont++;
		}		
	}while(numero != 0);
}
void numorden(){
	int numeros[100], numero;
	int temp=0; 			 //Variable temporal
	int i,j;			 //variables corredoras del ciclo
	for(i=1;i<numero;i++){
		for (j=0;j<numero-1;j++){
			if (numeros[j] > numeros[j+1]){	 //condicion
				temp = numeros[j];	 //temp guarda momentaneamente el valor de lista[j]
				numeros[j]=numeros[j+1];  //Asigno al la posicion lista[j], lo que hay en lista[j+1]
				numeros[j+1]=temp;	//obtendra un nuevo valor por parte de temp.
			}
		}
	}
	printf("\nLos valores ORDENADOS de lista son: \n");
	for(i=0;i<numero;i++){
		printf("%d", numeros[i]);
	}
	return 0;
}

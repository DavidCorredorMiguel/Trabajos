#include <stdio.h>
main(){
	int num, cont=0;
	for(num=13; num<=1000; num++){
		if(num%13 == 0){
			printf("%4d", num);
			cont++;
			if(cont%10 == 0){
				printf("\n");
			}
		}		
	}
	printf("\n\n===================================\n", num);
	int x;
	for(x=1; x<=100; x++){
		printf("%4d", x);
		
		if(x%10 == 0){
			printf("\n");
		}
	}
	printf("\n\n===================================\n", num);
}

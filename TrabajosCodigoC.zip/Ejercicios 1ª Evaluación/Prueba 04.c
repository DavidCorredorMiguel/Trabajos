#include <stdio.h>
#include <math.h>
main(){
	float num, media=0;
	int contador=0;
	do{
		printf("Introduce un numero: ");
		scanf("%f", &num);
		media += num;
		contador++;	
	}while(contador<5);
	media= media/5;
	printf("La media es: %g", media);
}

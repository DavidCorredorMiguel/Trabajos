#include <stdio.h>
// Declaraci�n de funciones
//void menu();
int menu();
void del1al10();
void del10al1();
void suma();
void suma2(int a, int b);
int suma3(int a, int b);
main(){
	// Declaraci�n de variables
	int opcion;
	int a, b, resultado;	
	do{
		//menu();	// Llamada a la funci�n men�
		//scanf("%d", &opcion);
		opcion = menu();
		switch(opcion){
			case 1:
				del1al10(); // Declaraci�n de funciones
				break;
			case 2:
				del10al1(); // Declaraci�n de funciones
				break;
			case 3:
				// Forma 1
				//suma(); // Declaraci�n de funciones
				// Forma 2
				/*printf("Introduzca un numero: ");
				scanf("%d", &a);
				printf("Introduzca otro numero: ");
				scanf("%d", &b);				
				suma2(a, b);*/				
				// Forma 3
				printf("Introduzca un numero: ");
				scanf("%d", &a);
				printf("Introduzca otro numero: ");
				scanf("%d", &b);				
				// Forma 3.1
				/*resultado = suma3(a, b);
				printf("La suma de %d + %d es %d", a, b, resultado);
				*/
				// Forma 3.2
				printf("La suma de %d + %d es %d", a, b, suma3(a, b));
				break;
		}
		printf("\n");
	}while(opcion != 0);
}
// Implementaci�n de funciones
/*void menu(){
	printf("\n\n1. Muestra del 1 al 10\n");
	printf("2. Muestra del 10 al 1\n");
	printf("3. Suma dos numeros\n");
	printf("0 Salir\n");
}*/
int menu(){
	int opcion; 
	printf("\n\n1. Muestra del 1 al 10\n");
	printf("2. Muestra del 10 al 1\n");
	printf("3. Suma dos numeros\n");
	printf("0 Salir\n");
	printf("Elija una opcion: ");
	scanf("%d", &opcion);
	return opcion;
}
void del1al10(){ // Estructura de funciones
	int num; // Declaraci�n de variables
	for(num=1; num<=10; num++){ // Bucle for
		printf("%d ", num);
	}
}
void del10al1(){ // Estructura de funciones
	int num; // Declaraci�n de variables
	for(num=10; num>=1; num--){ // Bucle for
		printf("%d ", num);
	}
}
void suma(){ // Estructura de funciones
	int a, b, total; // Declaraci�n de variables
	printf("Introduzca un numero: ");
	scanf("%d", &a);
	printf("Introduzca otro numero: ");
	scanf("%d", &b);
	// Realizar la suma de ambos n�meros
	total = a + b;
	printf("La suma de %d + %d es %d", a, b, total);
}
void suma2(int a, int b){ // Estructura de funciones
	int total = a + b; // Declaraci�n de variables
	printf("La suma de %d + %d es %d", a, b, total);
}
int suma3(int a, int b){ // Estructura de funciones
	return a + b;
}

#include <stdio.h>
main(){
	int fila;
	int columna;
	int x=65;
	for(fila=1; fila<=8; fila++){
		for(columna=1; columna<=8; columna++){
			printf("%c%d ", x, columna);
		}
		printf("\n");
		x++;
	}
}

#include <stdio.h>
#define MAX 100
main(){
	// Declaraci�n de variables
	float peso, altura, pesos[MAX], alturas[MAX];
	int x=0, cont=0;
	// Guardar en el array
	do{
		printf("Introduzca un peso: ");
		scanf("%f", &peso);
		printf("Introduzca una altura: ");
		scanf("%f", &altura);
		if(peso != -1 && altura != -1){
			pesos[x] = peso;
			alturas[x] = altura;
			x++;
			cont++;
		}
	}while(peso != -1 && altura != -1);
	// Recorremos los 2 arrays y calculamos el IMC
	for(x=0; x<cont; x++){
		printf("Con un peso de: %g kg y una altura de: %g m el indice de masa corporal es: %g\n\n", pesos[x], alturas[x], pesos[x]/(alturas[x]*alturas[x]));
	}
}

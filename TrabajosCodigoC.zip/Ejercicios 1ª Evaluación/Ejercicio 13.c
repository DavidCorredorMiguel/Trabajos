#include <stdio.h>
main(){
// declaraci�n de variables 
	int numero, fila, columna;
	//incializaci�n del bucle
	do{ 
		printf ("Introduce un numero entre el 3 y el 9:"); //Se pide por teclado al usuario un numero 
		scanf ("%i", &numero); // se guarda el n�mero introducido en la variable a 
	}while (numero<3|| numero>9); // El bucle termina si se cumple la condici�n 
	for(fila=1; fila<=numero; fila++){
		for(columna=1; columna<=numero; columna++){
			if(fila <= columna){
				printf("* ");
			}else{
				printf(" ");
			}
		}
		printf("\n");
	}
	for(fila=2; fila<=numero; fila++){	// variable para las columnas hasta el n�mero introducido por usuario
		for(columna=1; columna<=numero; columna++){	// variable para filas hasta " "	"		"	"			"..
			if(fila+columna>numero){	// condici�n que columna + fila sea mayor que n�mero
				printf("* ");	// si se cumple la condicion se muestra asteristico
			}else{	//si no se cumple no muestra nada 
				printf(" ");
			}
		}
		printf("\n");
	}
}

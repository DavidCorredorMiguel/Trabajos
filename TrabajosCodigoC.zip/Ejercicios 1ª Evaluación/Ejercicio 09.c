#include <stdio.h>

main(){
// Declaraci�n de variables
	int numero, fila, columna;
// Hacemos un bucle Do-While
	do{
		printf("Por favor introduce un numero entre 3 y 9: ");
		scanf("%d", &numero);
	}while(numero<3 || numero>9);
	
	
	for(fila=0; fila<numero; fila++){
		for(columna=0; columna<numero; columna++){
			if(columna<=4 || fila<=4){
				printf("* ");
			}
		}
		printf("\n");
	}
}

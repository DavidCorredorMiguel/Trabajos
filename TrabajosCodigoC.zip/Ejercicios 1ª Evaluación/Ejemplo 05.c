// Uso del switch
main(){
	int opcion=2; // Inicializaci�n
	switch(opcion){	// Estructura de selecci�n
		case 1:
			printf("Enero\n");
			break; // Estructura de salto
		case 2:
			printf("Febrero\n");
			break; // Estructura de salto
		case 3:
			printf("Marzo\n");
			break; // Estructura de salto
		case 4:
			printf("Abril\n");
			break; // Estructura de salto
		default:
			printf("Ese numero no esta contemplado");
	}
//Mismo codigo que el switch pero utilizando if
	if(opcion==1){ // Condici�n si
		printf("Enero\n");
	}else if(opcion==2){ // Condici�n si
		printf("Febrero\n");
	}else if(opcion==3){ // Condici�n si
		printf("Marzo\n");
	}else if(opcion==4){ // Condici�n si
		printf("Abril\n");
	}else{ // Condici�n si
		printf("numero no contemplado");
	}
	return 0;	
}



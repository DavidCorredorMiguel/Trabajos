#include <stdio.h>
main(){
	int numero, x;
	// Pedir un n�mero al usuario
	printf("Introduzca un numero: ");
	scanf("%d", &numero);
	for(x=1; x<=10; x++){
		printf("\n%2d x %2d = %2d", numero, x, numero*x);
	}
}

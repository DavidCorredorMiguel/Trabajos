#include <stdio.h>

main(){
	int fila;
	int columna;
	int opcion;
	
	do{
		printf("introduzca un numero del 3 al 9: ");
		scanf("%d", &opcion);	
	}while(opcion<3||opcion>9);
	
	for(fila=1;fila<=opcion;fila++){
		for(columna=1;columna<=opcion;columna++){
			if(columna>fila){
				printf("  ");
			}else{
				printf("*  ");
			}
		}	printf("\n");
	}
}

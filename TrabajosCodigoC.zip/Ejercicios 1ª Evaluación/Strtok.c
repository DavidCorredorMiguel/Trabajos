/*
Separa los nodos encontrados en una tabla HTML
*/
#include <stdio.h>
#include <string.h>
main(){
	char nombre[100]="<table><tr><td>Celda 1</td></tr><tr><td>Celda2</td></tr></table>";
	char delimitador[2]="<";
	char *token;
	token = strtok(nombre,delimitador);
	while (token !=NULL){
	printf("<%s\n",token);//Concatena "<" al principio para que aparezca el nodo completo
	token = strtok(NULL, delimitador);
	}
}

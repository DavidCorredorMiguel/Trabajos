// Crea un array de 100 posiciones. Pide al usuario que inserte numeros enteros hasta introducir 0. Muestra el array.
// Pide al usuario que elija una posicion y muestra el numero que tiene almacenado.
#include <stdio.h>
int main(){
	int numeros[100], numero;
	int cont=1;
	// Guardar en el array
	do{
		printf("Introduzca un numero: ");
		scanf("%d", &numero);
		if(numero != 0){
			numeros[cont] = numero;
			cont++;
		}		
	}while(numero != 0);
}

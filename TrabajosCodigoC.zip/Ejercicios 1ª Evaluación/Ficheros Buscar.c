#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 30
#define MAX 250
#define X 5

struct trabajadores
	{
	char nombre[N];
	int id;
	char comentario[MAX];
	}registro[X];
/*Prototipos*/
int buscar( char *nom );
int buscar( char *nom ){
	int i;
	for( i=0; i<X; i++ ){
		if( strcmp( registro[i].nombre, nom ) == 0 ){
			system( "clear" );
			printf( "Registro encontrado.. pulse para imprimir xD" );
			getchar();
			printf( "\n\nNombre: %s", registro[i].nombre );
			printf( "\nNumero de ID: %i", registro[i].id );
			printf( "%s", registro[i].comentario );
			return 1;
			}
		}
	return 0;
	}
int main()
	{
	char nombre[N];
	system( "clear" );   /*si usas Windows pon: "cls" en vez de "clear"*/
	printf( "Tu Nombre: " );
	gets( nombre ); 
	fflush(stdout);
	if( !buscar( nombre ) )
		printf( "Registro No Encontrado." );
	else {
	}printf( "\n\nRegistro Mostrado con Exito." );
	printf( "\n\n\nPulsa para salir.." );
	getchar();
	return 0;
	}

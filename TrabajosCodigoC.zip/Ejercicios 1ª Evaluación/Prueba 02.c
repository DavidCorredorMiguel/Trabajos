#include <stdio.h>
main(){
	float celsius, kelvin;	
	printf("Introduce grados celsius: \n");
	scanf("%f", &celsius);
	kelvin = celsius + 273.15;
	printf("%.2f grados celsius en kelvin = %.2f", celsius, kelvin);
}

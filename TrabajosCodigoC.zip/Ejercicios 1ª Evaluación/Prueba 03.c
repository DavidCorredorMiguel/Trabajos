#include <stdio.h>

// Declaraci�n de funciones
int cuadrado(int numero);
int cubo(int numero);
int cuarta(int numero);
int quinta(int numero);

main(){
	int x;
	
	printf("Introduzca un numero: ");
	scanf("%d", &x);
	printf("\nEl cuadrado de %d es: %d", x, cuadrado(x));
	printf("\nEl cubo de %d es: %d", x, cubo(x));
	printf("\nEl numero %d elevado a la cuarta es: %d", x, cuarta(x));
	printf("\nEl numero %d elevado a la quinta es: %d", x, quinta(x));
}

// Implementaci�n de funciones
int cuadrado(int numero){
	return numero*numero;
}

int cubo(int numero){
	return numero*numero*numero;
}

int cuarta(int numero){
	return numero*numero*numero*numero;
}

int quinta(int numero){
	return numero*numero*numero*numero*numero;
}

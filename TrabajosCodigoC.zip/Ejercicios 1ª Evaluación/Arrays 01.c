#include <stdio.h>
#define MAX 100
main(){
	// Declaraci�n de variables
	float edades[MAX], edad, media=0;
	int x, cont=0;
	// Guardar en el array
	do{
		printf("Introduzca una edad: ");
		scanf("%f", &edad);
		if(edad != -1){
			edades[cont] = edad;
			cont++;
		}		
	}while(edad != -1);
	// Recorrer el array para hacer la media de edades
	for(x=0; x<cont; x++){
		media += edades[x];
	}
	printf("La media de las edades introducidas es %g", media/cont);
	/*
	float edad, media=0;
	int cont=0;
	do{
		printf("Introduzca una edad: ");
		scanf("%f", &edad);
		if(edad != -1){
			media += edad;
			cont++;
		}		
	}while(edad != -1);
	printf("La media de las edades introducidas es %g", media/cont);
	*/
}

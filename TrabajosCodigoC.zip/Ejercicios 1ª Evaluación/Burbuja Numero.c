#include <stdio.h>
#define num 10
struct alu{
	char nombre[15];
	float calificacion;
};
void ordena(struct alu a,int n){
	a[num];
	int i,j;
	float t;
	for(i=1;i<num;i++);
	for(j=num-1;j>=i;--j)
	if(a[j]<a[j+1]){
	t=a[j]
	a[j]=a[j+1];
	a[j+1]=t;
	}
}
int imprimir
int registro(FILE *ap){
	int n=10,i;
	ap = fopen("lista.txt","a+");
	printf("\n\tLista de calificaciones\n");
	for(int i=0;i<10;i++){
		printf("\n\tNombre:");
		scanf("%s",&a[i].nombre);
		printf("\n\tCalificacion:");
		scanf("%f",&a[i].calificacion);
		fprintf(ap,"%s\t%f",a[i].nombre,a[i].calificacion);
	}
	ordena(a,n);
	printf("\nAlumno con mayor calificacion:");
	for(i=0;i<3;i++){
		printf("%.2f,%s",a[i].calificacion,a[i].nombre);
	}
}
int main(){
	struct alu;
	FILE *ap;
	registro(ap);
}

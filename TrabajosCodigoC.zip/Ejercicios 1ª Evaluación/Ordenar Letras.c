#include<stdio.h>
#include<string.h>
int main(){
//Variables
    char nombrealfabetico[10][20];
    char aux[20];//tiene que ser de igual o mayor tama�o que la segunda componente
    //de nombre porque aqu� copiaremos esa cadena.
    int ia,ja,ka;
    int l=0;
    //Fin Variables
	printf("Ingrese 20 productos y para terminar escriba * \n");
    do{
        printf("Ingrese nombre de Producto: ");
        scanf("%s",nombrealfabetico[l]);//lee cadenas y las almacena.
        l++;
    }while (strcmp(nombrealfabetico[l-1],"*")!=0);//permite comparar cadenas.

    // ORDENAR CADENAS
    for(ia=0; ia<l-1; ia++){
        ka=ia;
        strcpy(aux, nombrealfabetico[ia]);
        for(ja=ia+1; ja<l; ja++){
            if(strcmp(nombrealfabetico[ja], aux)<0){
                ka=ja;
                strcpy(aux, nombrealfabetico[ja]);
               //permite hacer una copia auxiliar de la cadena nombre[j];
            }
        }
        strcpy(nombrealfabetico[ka],nombrealfabetico[ia]);
        strcpy(nombrealfabetico[ia],aux);
    }
    for(ia=0; ia<l; ia++){
        printf("%s",nombrealfabetico[ia]);
        printf("\n");
    }
return 0;
}

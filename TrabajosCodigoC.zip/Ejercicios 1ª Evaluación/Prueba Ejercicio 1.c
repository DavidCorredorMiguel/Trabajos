/*
Pedir al usuario una cantidad y mostrar el menor n�mero de billetes y monedas de euro para devolver dicha cantidad
*/
// Incluye liber�a estandar
#include <stdio.h>
// Llamamos al Metodo principal
int main(){
	// Declaraci�n de variables
	int cantidad;
	int billetes500;
	int billetes200;
	int billetes100;
	int billetes50;
	int billetes20;
	int billetes10;
	int billetes5;
	int monedas2;
	int monedas1;
	int restos;
	printf("Introduce una cantidad: "); // Mostrar cantidad introducida
	scanf("%d", &cantidad);
	billetes500 = cantidad/500; //Sacar cantidad de billetes de 500 euros
	restos = cantidad%500;	//Pasar restos a las siguientes operaciones
	billetes200 = restos/200; //Sacar cantidad de billetes de 200 euros
	restos = restos%200;	//Pasar restos a las siguientes operaciones
	billetes100 = restos/100; //Sacar cantidad de billetes de 100 euros
	restos = restos%100;	//Pasar restos a las siguientes operaciones
	billetes50 = restos/50; //Sacar cantidad de billetes de 50 euros
	restos = restos%50;	//Pasar restos a las siguientes operaciones
	billetes20 = restos/20; //Sacar cantidad de billetes de 20 euros
	restos = restos%20;	//Pasar restos a las siguientes operaciones
	billetes10 = restos/10; //Sacar cantidad de billetes de 10 euros
	restos = restos%10;	//Pasar restos a las siguientes operaciones
	billetes5 = restos/5; //Sacar cantidad de billetes de 5 euros
	restos = restos%5;	//Pasar restos a las siguientes operaciones
	monedas2 = restos/2; //Sacar cantidad de monedas de 2 euros
	restos = restos%2;	//Pasar restos a las siguientes operaciones
	monedas1 = restos/1; //Sacar cantidad de monedas de 1 euro
	restos = restos%1;	//Pasar restos a las siguientes operaciones
	
	printf("\nLa cantidad a debolver es:"); // Mostrar cantidad a devolver
	printf("\n%d billetes de 500", billetes500); // Mostrar billetes de 500 euros
	printf("\n%d billetes de 200", billetes200); // Mostrar billetes de 200 euros
	printf("\n%d billetes de 100", billetes100); // Mostrar billetes de 100 euros
	printf("\n%d billetes de 50", billetes50); // Mostrar billetes de 50 euros
	printf("\n%d billetes de 20", billetes20); // Mostrar billetes de 20 euros
	printf("\n%d billetes de 10", billetes10); // Mostrar billetes de 10 euros
	printf("\n%d billetes de 5", billetes5); // Mostrar billetes de 5 euros
	printf("\n%d monedas de 2", monedas2); // Mostrar monedas de 2 euros
	printf("\n%d monedas de 1", monedas1); // Mostrar monedas de 1 euro
	return 0;
}

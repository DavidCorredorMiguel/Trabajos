#include <stdio.h>
main(){
	int dividendo, divisor, restos, numero;
	printf("Introduzca un numero: ");
	scanf("%d", &numero);
	for(dividendo=2; dividendo<=numero; dividendo++){
		restos=0;	// Inicializamos a cero en cada nuevo dividendo
		for(divisor=2; divisor<dividendo; divisor++){
			if(dividendo%divisor == 0){
				restos++;
			}
		}
		// Tras realizar todas las divisiones
		if(restos == 0){
			printf("%d ", dividendo);
		}
	}
}

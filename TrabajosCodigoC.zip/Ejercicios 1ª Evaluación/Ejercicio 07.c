#include <stdio.h>
int menu();
void suma();
void resta();
void multiplicar();
void dividir();
main(){
	int opcion;
	int a, b, resultado;	
	do{
		opcion = menu();
		switch(opcion){
			case 1:
				suma();
				printf("Introduzca un primer numero: ");
				scanf("%d", &a);
				printf("Introduzca un segundo numero: ");
				scanf("%d", &b);
				break;
			case 2:
				resta();
				printf("Introduzca un primer numero: ");
				scanf("%d", &a);
				printf("Introduzca un segundo numero: ");
				scanf("%d", &b);
				break;
			case 3:
				multiplicar();
				printf("Introduzca un primer numero: ");
				scanf("%d", &a);
				printf("Introduzca un segundo numero: ");
				scanf("%d", &b);
				break;
			case 4:
				dividir();
				printf("Introduzca un primer numero: ");
				scanf("%d", &a);
				printf("Introduzca un segundo numero: ");
				scanf("%d", &b);
				break;
		}
		printf("\n");
	}while(opcion != 0);
}
int menu(){
	int opcion;
	printf("CALCULADORA BRUTAL: \n");
	printf("1. Sumar\n");
	printf("2. Restar\n");
	printf("3. Multiplicar\n");
	printf("4. Dividir\n");
	printf("0. Salir\n");
	printf("Elija una opcion: ");
	scanf("%d", &opcion);
	return opcion;
}
void suma(){
	int a, b, total;
	printf("Introduzca un primer numero: ");
	scanf("%d", &a);
	printf("Introduzca un segundo numero: ");
	scanf("%d", &b);
	total = a + b;
	printf("%d + %d = %d\n", a, b, total);
}
void resta(){
	int a, b, total;
	printf("Introduzca un primer numero: ");
	scanf("%d", &a);
	printf("Introduzca un segundo numero: ");
	scanf("%d", &b);
	total = a - b;
	printf("%d - %d = %d\n", a, b, total);
}
void multiplicar(){
	int a, b, total;
	printf("Introduzca un primer numero: ");
	scanf("%d", &a);
	printf("Introduzca un segundo numero: ");
	scanf("%d", &b);
	total = a * b;
	printf("%d * %d = %d\n", a, b, total);
}
void dividir(){
	int a, b, total;
	printf("Introduzca un primer numero: ");
	scanf("%d", &a);
	printf("Introduzca un segundo numero: ");
	scanf("%d", &b);
	total = a / b;
	printf("%d / %d = %d\n", a, b, total);
}

/*
Lee y muestra el primer car�cter.
Si no encuentra el fichero (o no lo puede abrir) lo indica.
*/
#include <stdio.h>
main(){
	FILE *fichero;
	fichero = fopen("datos.txt", "r");
	char letra=getc(fichero);
	if (letra==EOF) {
		printf("Fichero no encontrado");
	} else {
		printf("%c", letra);
	}
	fclose(fichero);
}

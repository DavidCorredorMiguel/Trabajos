#include <stdio.h>
#define tamano 10
void main(void){ 
  int vNumeros[tamano]; 
  int j, i, temp;
  printf ("Introduce los %d n�meros a ordenar:\n", tamano);   
  /* Obtenemos los 10 n�meros y los guardamos en vNumeros */
  for (i = 0; i < tamano; i++){ 
    printf ("%d: ", i + 1); 
    scanf ("%d", &vNumeros[i]); 
    printf ("\n"); 
  } 
  
  /* Ordenamos los n�meros del vector vNumeros por el m�todo de burbuja */
  for (i = 0; i < (tamano - 1); i++){ 
    for (j = i + 1; j < tamano; j++) { 
      if (vNumeros[j] < vNumeros[i]){ 
        temp = vNumeros[j]; 
        vNumeros[j] = vNumeros[i]; 
        vNumeros[i] = temp; 
      } 
    } 
  } 
  
  /* Mostramos los n�meros ordenados */
  printf ("Los n�meros ordenados son:\n"); 
  for (i = 0; i < tamano; i++){ 
    printf("%d, ", vNumeros[i]); 
  }
  system("PAUSE");  
}

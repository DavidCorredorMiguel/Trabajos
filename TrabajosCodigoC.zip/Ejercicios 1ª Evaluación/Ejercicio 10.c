#include <stdio.h>

main(){
// Declaraci�n de variables
	int opcion, fila, columna;
// Hacemos un bucle Do-While
	do{
		printf ("Por favor introduzca un numero entre 3 y 9:");
		scanf("%d", &opcion);
	}while(opcion<=3 || opcion>=9);
	for(fila=1; fila<=opcion; fila ++){
		for(columna=1; columna<=opcion; columna ++){
			if (fila>=2 && fila<opcion&& columna>=2 && columna<opcion){
				printf("  ");
			}else{
				printf("* ");
			}
		}
		printf("\n");
	}
}


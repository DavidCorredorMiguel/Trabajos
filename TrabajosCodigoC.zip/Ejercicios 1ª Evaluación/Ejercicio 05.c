#include <stdio.h>
main(){
	int numero;
	do{
		printf("Introduzca un dia de la semana en numero: ");
		scanf("%d", &numero);
		switch(numero){
			case 1: 
				printf("Lunes\n\n");
				break;
			case 2: 
				printf("Martes\n\n");
				break;
			case 3: 
				printf("Miercoles\n\n");
				break;
			case 4: 
				printf("Jueves\n\n");
				break;
			case 5: 
				printf("Viernes\n\n");
				break;
			case 6: 
				printf("Sabado\n\n");
				break;
			case 7: 
				printf("Domingo\n\n");
				break;
			case 0: 
				printf("Ciao pescao\n\n");
				break;
			default:
				printf("El numero esta fuera de rango\n\n");
		}
	}while(numero != 0);
}

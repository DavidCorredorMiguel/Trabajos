#include <stdio.h>
main(){
	// Declaraci�n de variables
	int opcion;
	int num;
	// Bucle do-while
	do {
		printf("1. Escribe del 1 al 10\n");
		printf("2. Escribe del 10 al 1\n");
		printf("0. Salir\n");
		printf("=======================\n");
		printf("Introduce una opcion:");
		scanf("%d", &opcion);
	//printf("Has introducido%d\n", opcion);
		switch(opcion){
			case 1:
			for(num=1; num<=10; num++){ // Bucle for
				printf("%d.", num);
			}
			break; // Estructura de salto
			case 2:
			for(num=10; num>=1; num--){ // Bucle for
				printf("%d.", num);
			}
		}
	}while (opcion!=0);
}

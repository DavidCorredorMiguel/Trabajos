#include <stdlib.h>
main(){
	int x, num;
	printf("elige un numero: ");
	scanf("%d", &x);
	srand (getpid());
	num=(rand()%9)+1;
	if(x==num){
		printf("Enhorabuena has acertado!!");
		printf("\n ha salido: %d", num);
	}else{
		printf("Vuelve a intentarlo");
		printf("\n ha salido: %d", num);
	}
}

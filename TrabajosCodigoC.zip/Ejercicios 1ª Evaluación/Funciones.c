#include <stdio.h>
int getEdad(); 
main(){  
	int edad = getEdad();
	printf ("Tienes %d anyos", edad);
}
int getEdad(){
	int edad;
	printf("Dime tu edad:");
	scanf("%d", &edad);
	return edad;
} 

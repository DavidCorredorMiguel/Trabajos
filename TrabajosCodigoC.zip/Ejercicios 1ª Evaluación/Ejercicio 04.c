main(){
	int opcion;
	int num1;	// Inicializaci�n
	int num2;
	int resultado;
	do{
		printf("Bienvenidos a nuestro primer menu:\n");
		printf("1. Te daremos las buenas tardes.\n");
		printf("2. Te daremos la posibilidad de sumar dos numeros.\n");
		printf("3. Te recordaremos que el grupo A siempre fue mejor que el B.\n");
		printf("0. SALIR\n");
		printf("Por favor, elija una opcion.\n");
		scanf("%d", &opcion);
		switch(opcion){
			case 1:
				printf("Buenas tardes.\n\n");
				break;
			case 2:
				printf("Suma dos numeros.\n\n");
				printf("Introduzca un primer numero: ");
				scanf("%d", &num1);
				printf("Introduzca un segundo numero: ");
				scanf("%d", &num2);
				resultado= num1+num2;
				printf("%d + %d = %d\n", num1, num2, resultado);
				break;
			case 3:
				printf("El grupo A siempre fue mejor que el B.\n\n");
				break;
			case 0:
				printf("Saliendo\n");
				break;
		}
	}while(opcion != 0);
}

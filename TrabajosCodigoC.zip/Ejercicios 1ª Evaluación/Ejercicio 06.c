#include <stdio.h>
main(){
	int numero;
	do{	
	printf("\nIntroduzca un mes en numero del 1 al 12 (0 para salir): ");
	scanf("%d", &numero);
		switch(numero){
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				printf("El mes %d tiene 31 dias", numero);
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				printf("El mes %d tiene 30 dias", numero);
				break;	
			case 2:
				printf("El mes %d tiene 28 o 29 dias", numero);
				break;
			case 0:
				printf("Salir", numero);
				break;	
		}
		getch();
	}while(numero!= 0);
}

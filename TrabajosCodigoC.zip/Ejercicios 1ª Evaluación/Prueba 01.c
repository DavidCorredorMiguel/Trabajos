#include <stdio.h>
main(){
	float peso, altura, resultado;	
	printf("Introduce tu peso: \n");
	scanf("%f", &peso);
	printf("Introduce tu altura: \n");
	scanf("%f", & altura);
	altura=altura*altura;
	resultado = peso/altura;
	printf("El IMC con un peso de %g y una altura de %g = %g", peso, altura, resultado);
}

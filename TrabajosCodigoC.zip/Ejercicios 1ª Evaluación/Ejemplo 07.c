// Bucle do..while
// Sirve para crear men�s de opciones
// Al menos se ejecuta una vez

main(){
	int numero=1;	// Inicializaci�n
	int salir = 0;
	do{
		printf("1. Abrir\n");
		printf("2. Guardar\n");
		printf("3. Buscar\n");
		printf("4. Imprimir\n");
		printf("0. SALIR\n");
		switch(numero){
			case 1:
				printf("Abriendo\n\n");
				break; // Estructura de salto
			case 2:
				printf("Guardando\n\n");
				break; // Estructura de salto
			case 3:
				printf("Buscando\n\n");
				break; // Estructura de salto
			case 4:
				printf("Imprimiendo\n\n");
				numero=-1;
				break; // Estructura de salto
			case 0:
				printf("Saliendo\n");
				salir=1;
				break; // Estructura de salto
		}
		numero++; // Incremento
	}while(salir != 1);
}

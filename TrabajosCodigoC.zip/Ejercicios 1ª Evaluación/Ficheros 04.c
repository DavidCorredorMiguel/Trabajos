/*
Escribe lo introducido por teclado.
*/
#include <stdio.h>
main(){
	FILE *fichero;
	char linea[80];
	fichero = fopen("datos.txt", "a");
	printf("Escribe algo:");
	gets(linea);
	fprintf(fichero,"%s",linea);
	fclose(fichero);
}

// Crea una matriz de tama�o 3x3. Pide al usuario que inserte numeros enteros hasta rellenarla. Muestra la matriz. 
// Suma los n�meros de las esquinas de la matriz, resta los que estan entre ellos y multiplica todo po el elemento central.
int main(){
	int matriz[3][3] ={
	{3,4,5},
	{8,1,9},
	{2,0,7}
	};
	printf ("%i", matriz[1][2]); 
}


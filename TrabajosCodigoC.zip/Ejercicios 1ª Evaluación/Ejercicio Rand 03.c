#include<stdio.h>
#include<time.h>
int main(){
	int n;
	int c;
	int m;
	srand(time(NULL));
	
	for(n=1;n<=14;n++){
		printf("%2d.",n);
		for(c=1;c<=3;c++){
			m=1+(rand()%3);
			if(m==3){
				printf(" 1            ");
			}else if(m==2){
				printf("   X          ");
			}else if(m==1){
				printf("      2       ");
			}
		}
		printf("\n");
	}
	return 0;
}

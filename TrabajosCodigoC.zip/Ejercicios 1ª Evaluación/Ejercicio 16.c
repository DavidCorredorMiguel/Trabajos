#include <stdio.h>

main(){
	//declaro la variable
	int nota;
	//creo un do while para repetir el contenido si los valores no estan comprendidos
	//dentro del while.
	do{
		//pedimos la nota entre 1 y 10(incluidos)
		printf("La nota del boletin de notas es: ");
		scanf("%d", &nota);
		
		//dependiendo la nota se entra por un 'case' y debido a que no hay break
		//hasta ciertos valores sigue pasando de case y realizando todo lo interno.
		switch(nota){
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				printf("insuficiente");
				break;
			case 5:
				printf("Bien");	
				break;
			case 6:
			case 7:
			case 8:
				printf("Notable");
				break;
			case 9:
			case 10:
				printf("Sobresaliente");
				break;	
		}
	//este while esta acortando el rango de la variable nota.
	//si cumple alguno de estos valores vuelve a comenzar el 'do'	
	}while(nota<0 || nota>10);
}
//terminado por fin!! hasta ma�ana

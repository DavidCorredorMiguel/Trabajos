#include <stdio.h>
main(){
	int dia, mes;
	printf("Introduzca un dia de mes: ");
	scanf("%d", &dia);
	printf("Introduzca un mes: ");
	scanf("%d", &mes);
	if(dia >= 21 && dia <=31 && mes == 3 || dia >= 1 && dia <=19 && mes == 4){
		printf("Aries");
	}else if(dia >= 20 && dia <=30 && mes == 4 || dia >= 1 && dia <=20 && mes == 5){
		printf("Tauro");
	}else if(dia >= 21 && dia <=31 && mes == 5 || dia >= 1 && dia <=20 && mes == 6){
		printf("Geminis");
	}else if(dia >= 21 && dia <=30 && mes == 6 || dia >= 1 && dia <=22 && mes == 7){
		printf("Cancer");
	}else if(dia >= 23 && dia <=31 && mes == 7 || dia >= 1 && dia <=22 && mes == 8){
		printf("Leo");
	}else if(dia >= 23 && dia <=31 && mes == 8 || dia >= 1 && dia <=22 && mes == 9){
		printf("Virgo");
	}else if(dia >= 23 && dia <=30 && mes == 9 || dia >= 1 && dia <=22 && mes == 10){
		printf("Libra");
	}else if(dia >= 23 && dia <=31 && mes == 10 || dia >= 1 && dia <=21 && mes == 11){
		printf("Escorpio");
	}else if(dia >= 22 && dia <=31 && mes == 11 || dia >= 1 && dia <=19 && mes == 12){
		printf("Capricornio");
	}else if(dia >= 20 && dia <=31 && mes == 12 || dia >= 1 && dia <=21 && mes == 1){
		printf("Sagitario");
	}else if(dia >= 22 && dia <=31 && mes == 1 || dia >= 1 && dia <=18 && mes == 2){
		printf("Acuario");
	}else if(dia >= 19 && dia <=29 && mes == 2 || dia >= 1 && dia <=20 && mes == 3){
		printf("Piscis");
	}
}

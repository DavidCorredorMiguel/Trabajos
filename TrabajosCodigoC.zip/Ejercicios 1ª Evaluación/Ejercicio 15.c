#include <stdio.h>
int main(){
	int x, y, z;
	printf("dime 3 numeros");
	scanf("%d", &x);
	printf("dime 3 numeros");
	scanf("%d", &y);	
	printf("dime 3 numeros");
	scanf("%d", &z);
	if(x<y && x<z){
		if(y<z){
			printf("%d, %d, %d", x,y,z);
		}else{
			printf("%d, %d, %d", x,z,y);
		}
		
	}else if(y<z && y<x){
			if(z<x){
			printf("%d, %d, %d", y,z,x);
		}else{
			printf("%d, %d, %d", y,x,z);
		}
	}else{
		if(y<x){
			printf("%d, %d, %d", z,y,x);
		}else{
			printf("%d, %d, %d", z,x,y);
		}
	}
}

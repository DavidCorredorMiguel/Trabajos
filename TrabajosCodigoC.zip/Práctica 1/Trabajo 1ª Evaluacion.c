// Declaro libreria
#include <stdio.h>
#include <string.h>
// Declaraci�n de la estructura global
struct pelicula{
	char nombre[100];
	int anio;
	char pais[100];
	int presupuesto;
	char genero[100];
	char imagen[100];
};
// Declaro arrays de estructuras global para utilizarlos en toda la aplicacion
struct pelicula peli[100];
// Declaraci�n de la funci�n
int menu();
int menuorden();
void leerFichero();
void agregapeli();
void consultarlista();
void consultarpeli();
void consultarpelisordenadas();
void generarHTMLespecifico();
void generarHTML();
// Llamo al metodo principal
int main(){
	int opcion;
	leerFichero(); // Te lleva hasta el void
	// Un do-while en el que estar� men� y el switch
	do{
		opcion=menu();
		while(getchar()!='\n'); // Vac�a el buffer de entrada
		switch(opcion){
			case 1:
				system("cls"); // Abre nueva pantalla
				agregapeli(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 2:
				system("cls"); // Abre nueva pantalla
				consultarlista(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 3:
				system("cls"); // Abre nueva pantalla
				consultarpeli(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 4:
				system("cls"); // Abre nueva pantalla
				consultarpelisordenadas(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 5:
				system("cls"); // Abre nueva pantalla
				generarHTMLespecifico(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 6:
				system("cls"); // Abre nueva pantalla
				generarHTML(); // Te lleva hasta el void
				getch(); // Saca por pantalla la tecla pulsada
				break; // Cierra el case
			case 0:
				break; // Cierra el case
		}
	}while(opcion!=0);
	// Llamo a las funciones dentro de un switch
	return 0;
}
int menu(){
	int opcion;
	printf("1. Agregar pelicula\n");
	printf("2. Consultar listado de peliculas\n");
	printf("3. Consultar pelicula\n");
	printf("4. Consultar listado de peliculas ordenado\n");
	printf("5. Generar documento especifico HTML\n");
	printf("6. Generar documentos HTML\n");
	printf("0. SALIR\n");
	printf("Introduzca un numero: ");
	scanf("%d", &opcion);
	return opcion;
}
void leerFichero(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	char linea[100];
	struct pelicula peli[100];
	int x=0;
	int numPelis=0;
	fichero=fopen("Peliculas.txt", "r"); // Abre el fichero
	while((fgets(linea, 100, fichero))!=NULL){ // Lee todas las lineas del fichero
		if(linea==0){ //Recoges datos primera linea
			strcpy(peli[x].nombre, linea); // Copia a la estructura
			printf(peli[x].nombre);
			numPelis++;
		}else if(linea==1){ //Recoges datos segunda linea
			peli[x].anio = linea; // Consulta a la estructura
			printf(peli[x].anio);
			numPelis++;
		}else if(linea==2){ //Recoges datos tercera linea
			strcpy(peli[x].pais, linea); // Copia a la estructura
			printf(peli[x].pais);
			numPelis++;
		}else if(linea==3){ //Recoges datos cuarta linea
			peli[x].presupuesto = linea; // Consulta a la estructura
			printf(peli[x].presupuesto);
			numPelis++;
		}else if(linea==4){ //Recoges datos quinta linea
			strcpy(peli[x].genero, linea); // Copia a la estructura
			printf(peli[x].genero);
			numPelis++;
		}else if(linea==5){ //Recoges datos sexta linea
			strcpy(peli[x].imagen, linea); // Copia a la estructura
			printf(peli[x].imagen);
			numPelis++;
			x++;
		}
	}
	fclose(fichero);
}
void agregapeli(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	char nombreActual[100];
	int anioActual;
	char paisActual[100];
	int presupuestoActual;	
	char generoActual[100];
	char imagenActual[100];
	int x;
	fichero=fopen("Peliculas.txt", "a"); // Abre el fichero
	printf("Introduce nombre de la peli: ");
	gets(nombreActual); // Lee datos
	strcpy(peli[x].nombre, nombreActual); // Copia a la estructura
	fprintf(fichero, "%s", peli[x].nombre); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	printf("Introduce anio de la peli: ");
	scanf("%d", &anioActual);
	peli[x].anio = anioActual; // Consulta a la estructura
	fprintf(fichero, "%d", peli[x].anio); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	while(getchar()!='\n'); // Vac�a el buffer de entrada
	printf("Introduce pais de la peli: ");
	gets(paisActual); // Lee datos
	strcpy(peli[x].pais, paisActual); // Copia a la estructura
	fprintf(fichero, "%s", peli[x].pais); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	printf("Introduce presupuesto de la peli: ");
	scanf("%d", &presupuestoActual);
	peli[x].presupuesto = presupuestoActual; // Consulta a la estructura
	fprintf(fichero, "%d", peli[x].presupuesto); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	while(getchar()!='\n'); // Vac�a el buffer de entrada
	printf("Introduce genero de la peli: ");
	gets(generoActual); // Lee datos
	strcpy(peli[x].genero, generoActual); // Copia a la estructura
	fprintf(fichero, "%s", peli[x].genero); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	printf("Introduce imagen de la peli: ");
	gets(imagenActual); // Lee datos
	strcpy(peli[x].imagen, imagenActual); // Copia a la estructura
	fprintf(fichero, "%s", peli[x].imagen); // Escribes en el fichero
	putc('\n', fichero); // Salto de linea
	fclose(fichero);
}
void consultarlista(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	struct pelicula peli[100];
	char linea[100];
	int num, contador;
	int x=0;
	fichero=fopen("Peliculas.txt", "r"); // Abre el fichero
	while((fgets(linea, "%s", fichero))!=NULL){ // Lee todas las lineas del fichero
		if(contador%6==0){
			strcpy(peli[x].nombre, linea); // Copia y consulta la cadena nombre
			printf("Nombre: %s", peli[x].nombre); // Muestra el nombre
		}else if(contador%6==1){ //Recoges datos segunda linea
			peli[x].anio = linea; // Consulta la cadena anio
			printf("Anio: %s", peli[x].anio); // Muestra el anio
		}
		else if(contador%6==2){ //Recoges datos tercera linea
			strcpy(peli[x].pais, linea); // Copia y consulta la cadena pais
			printf("Pais: %s", peli[x].pais); // Muestra el pais
		}
		else if(contador%6==3){ //Recoges datos cuarta linea
			peli[x].presupuesto = linea; // Consulta la cadena presupuesto
			printf("Presupuesto: %s", peli[x].presupuesto); // Muestra el presupuesto
		}
		else if(contador%6==4){ //Recoges datos quinta linea
			strcpy(peli[x].genero, linea); // Copia y consulta la cadena genero
			printf("Genero: %s", peli[x].genero); // Muestra el genero
		}
		else if(contador%6==5){ //Recoges datos sexta linea
			strcpy(peli[x].imagen, linea); // Copia y consulta la cadena imagen
			printf("Imagen: %s", peli[x].imagen); // Muestra la imagen
			x++;
		}
	contador++;
	}
	fclose(fichero);
}
void consultarpeli(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	char nombrePeli[100];
	int x=0, numeropelis;
	struct pelicula pelis[100];
	printf("Dime el nombre de la peli: ");
	gets(nombrePeli); // Lee datos
	fichero=fopen("Peliculas.txt", "r"); // Abre el fichero
	char delimitador[2]=" ";
	char *token;  
	token = strtok(nombrePeli,delimitador); 
	while(token !=NULL){ // Lee todas las lineas
	token = strtok(NULL, delimitador); 
		if(strcmp(peli[x].nombre, nombrePeli)!=NULL){ // Compara las cadenas
			printf("Nombre: %s", peli[x].nombre, token); // Muestra el nombre
			printf("Anio: %d", peli[x].anio, token); // Muestra el anio
			printf("Pais: %s", peli[x].pais, token); // Muestra el pais
			printf("Presupuesto: %d", peli[x].presupuesto, token); // Muestra el presupuesto
			printf("Genero: %s", peli[x].genero, token); // Muestra el genero
			printf("Imagen: %s", peli[x].imagen, token); // Muestra la imagen
			x++;
		}
	}
}
void consultarpelisordenadas(){
	int menuorden(){
		int opcionorden;
		printf("1. Ordenadas Por Nombre\n");
		printf("2. Ordenadas Por Anio\n");
		printf("3. Ordenadas Por Genero\n");
		printf("Introduzca un numero: ");
		scanf("%d", &opcionorden);
		return opcionorden;
	}	
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	struct pelicula peli[100];
	int aux;
	int opcionorden;
	char nombre[100];
	int n=6, variable, x;
	int i, j; // Variables corredoras del ciclo
	fichero=fopen("Peliculas.txt", "r"); // Abre el fichero
	do{
		opcionorden=menuorden();
		switch(opcionorden){
			case 1:
				printf("1. Ordenadas Por Nombre\n");
				variable=strcmp(peli[j].nombre, peli[i].nombre); // Compara las cadenas
					for(i=0; i<n; i++){
						for(j=0; j<n-1; j++){
							if(peli[j].nombre >peli[i].nombre){
								//aux guarda momentaneamente el caracter de lista[i]
								aux = nombre[i];
								//Asigno al la posicion lista[i], lo que hay en lista[j]
								nombre[i] = nombre[j];
								//obtendra un nuevo caracter por parte de aux
								nombre[j] = aux;
							}
						}
					}
					for (x=0;x<n;x++){
						printf("Nombre: %s", peli[x].nombre); // Muestra el nombre	
						printf("Anio: %d", peli[x].anio); // Muestra el anio
						printf("Pais: %s", peli[x].pais); // Muestra el pais
						printf("Presupuesto: %d", peli[x].presupuesto); // Muestra el presupuesto
						printf("Genero: %s", peli[x].genero); // Muestra el genero
						printf("Imagen: %s", peli[x].imagen); // Muestra la imagen
						x++;
					}
				break;
			case 2:
				system("cls"); //Abre nueva pantalla
				printf("2. Ordenadas Por Anio\n");
				getch();
				break;
			case 3:
				system("cls"); //Abre nueva pantalla
				printf("3. Ordenadas Por Genero\n");
				getch();
				break;
			case 0:
				break;
		}
	}while(opcionorden!=0);
	// Llamo a las funciones dentro de un switch
	return 0;
	fclose(fichero);
}
void generarHTMLespecifico(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	char aux[100];
	char html[100]=".html";
	int x=0;
	int numeropelis;
	fichero=fopen("Peli.html", "w"); // Abre el fichero
	printf("Introduce nombre de la peli: ");
	gets(fichero); // Lee datos
	while(strcmp(fichero, peli[x].nombre)!=0 && x<numeropelis){ // Compara las cadenas
		if(strcmp(fichero, peli[x].nombre)==0){  // Compara las cadenas
			strcat(peli[x].nombre, html);
			fprintf(fichero, "<!DOCTYPE html>");
			fprintf(fichero, "<html lang='es'>");
			fprintf(fichero, "<head>");
			fprintf(fichero, "<meta charset='UTF-8'>");
			fprintf(fichero, "</head>");
			fprintf(fichero, "<body background='Fondo.jpg'>");
			fprintf(fichero, "<b><u><center>Nombre:</u> %s</b>", peli[x].nombre);
			fprintf(fichero, "<br><br>");
			fprintf(fichero, "<b><u><center>A�o:</u> %d</b>", peli[x].anio);
			fprintf(fichero, "<br><br>");
			fprintf(fichero, "<b><u><center>Pa�s:</u> %s</b>", peli[x].pais);
			fprintf(fichero, "<br><br>");
			fprintf(fichero, "<b><u><center>Presupuesto:</u> %d$</b>", peli[x].presupuesto);
			fprintf(fichero, "<br><br>");
			fprintf(fichero, "<b><u><center>G�nero:</u> %s</b>", peli[x].genero);
			fprintf(fichero, "<br><br>");
			fprintf(fichero, "<b><u><center>Imagen:</u> <br><br><img src='%s'></b>", peli[x].imagen);
			fprintf(fichero, "</body>");
			fprintf(fichero, "</html>");	
			x++;	
		}	
	}
	fclose(fichero);
}
void generarHTML(){
	FILE *fichero; // Lee el fichero
	//Declaracion e Inicializacion del array
	int x=0;
	fichero=fopen("ListaPelis.html", "a"); // Abre el fichero
	fprintf(fichero, "<!DOCTYPE html>");
	fprintf(fichero, "<html lang='es'>");
	fprintf(fichero, "<head>");
	fprintf(fichero, "<meta charset='UTF-8>'");
	fprintf(fichero, "<title><center><h1><u>Peliculas</u></h1></center></title>");
	fprintf(fichero, "</head>");
	fprintf(fichero, "<body background='Fondo.jpg'>");
	fprintf(fichero, "<table>");
	fprintf(fichero, "<tr>");
	fprintf(fichero, "<td><a title=Vengadores Endgame href='Pelicula 1.html'><img src='Vengadores Endgame.jpg'</b></td>");
	fprintf(fichero, "<td><a title=Matrix href='Pelicula 2.html'><img src='Matrix.jpg'></b></td>");
	fprintf(fichero, "<td><a title=La Llamada href='Pelicula 3.html'><img src='La Llamada.jpg'></b></td>");
	fprintf(fichero, "<td><a title=Jurassic World El Reino Caido href='Pelicula 4.html'><img src='Jurassic World El Reino Caido.jpg'></b></td>");
	fprintf(fichero, "<td><a title=%s href='Peli.html'><img src='%s'></b></td>", peli[x].imagen);
	fprintf(fichero, "</tr>");
	fprintf(fichero, "</table>");
	fprintf(fichero, "</body>");
	fprintf(fichero, "</html>");
	fclose(fichero);
}
